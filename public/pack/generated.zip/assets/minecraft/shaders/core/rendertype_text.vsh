#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_1d5599eb(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ce042851() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_1f04c030(inout vec4 vertex) {
    f_1d5599eb(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ce042851();
    }
    finalize();
}



void f_d92a6f36() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_ff56c4d1() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_1362183f(inout vec4 vertex) {
    f_1d5599eb(vertex);
    f_d92a6f36();
    finalize();
}

void f_b1fdf844(inout vec4 vertex) {
    f_1d5599eb(vertex);
    f_ce042851();
    f_ff56c4d1();
    finalize();
}

void f_7a73d6f1(inout vec4 vertex) {
    f_1d5599eb(vertex);
    f_ff56c4d1();
    f_d92a6f36();
    finalize();
}

void f_3698683f(inout vec4 vertex) {
    f_ce042851();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1d5599eb(vertex);
    finalize();
}

void f_9d253df1(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_d92a6f36();
    f_1d5599eb(vertex);
    finalize();
}

void f_dcc76455(inout vec4 vertex, float speed) {
    f_1d5599eb(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_0473d568(inout vec4 vertex) {
    f_1d5599eb(vertex);
    f_ce042851();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_1f04c030(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ce042851();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_1d5599eb(vertex);
            f_ce042851();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b1fdf844(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b1fdf844(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_3698683f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_3698683f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_dcc76455(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_0473d568(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_1362183f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b1fdf844(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_7a73d6f1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_3698683f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_9d253df1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_dcc76455(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_1362183f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b1fdf844(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_7a73d6f1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_3698683f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_9d253df1(vertex);
        return;
    }
    

    
    f_1d5599eb(vertex);
    f_ce042851();
    finalize();
}