#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_8912908c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_81ff0d9a() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_bcbc5abd(inout vec4 vertex) {
    f_8912908c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_81ff0d9a();
    }
    finalize();
}



void f_fc8c29c0() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_5ab15a5c() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_73508ac2(inout vec4 vertex) {
    f_8912908c(vertex);
    f_fc8c29c0();
    finalize();
}

void f_b90ba438(inout vec4 vertex) {
    f_8912908c(vertex);
    f_81ff0d9a();
    f_5ab15a5c();
    finalize();
}

void f_3ab93b29(inout vec4 vertex) {
    f_8912908c(vertex);
    f_5ab15a5c();
    f_fc8c29c0();
    finalize();
}

void f_dc773b59(inout vec4 vertex) {
    f_81ff0d9a();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_8912908c(vertex);
    finalize();
}

void f_4132ba9b(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_fc8c29c0();
    f_8912908c(vertex);
    finalize();
}

void f_58c3279e(inout vec4 vertex, float speed) {
    f_8912908c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_e8a856fb(inout vec4 vertex) {
    f_8912908c(vertex);
    f_81ff0d9a();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_bcbc5abd(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_81ff0d9a();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_8912908c(vertex);
            f_81ff0d9a();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b90ba438(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b90ba438(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_dc773b59(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_dc773b59(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_58c3279e(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_e8a856fb(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_73508ac2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b90ba438(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_3ab93b29(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_dc773b59(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_4132ba9b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_58c3279e(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_73508ac2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b90ba438(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_3ab93b29(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_dc773b59(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_4132ba9b(vertex);
        return;
    }
    

    
    f_8912908c(vertex);
    f_81ff0d9a();
    finalize();
}