#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a3a413ca(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_f52ac82d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_f6332758(inout vec4 vertex) {
    f_a3a413ca(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_f52ac82d();
    }
    finalize();
}



void f_7fa2c79b() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_b76402cc() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_014e1b26(inout vec4 vertex) {
    f_a3a413ca(vertex);
    f_7fa2c79b();
    finalize();
}

void f_59c9beac(inout vec4 vertex) {
    f_a3a413ca(vertex);
    f_f52ac82d();
    f_b76402cc();
    finalize();
}

void f_f506c5f6(inout vec4 vertex) {
    f_a3a413ca(vertex);
    f_b76402cc();
    f_7fa2c79b();
    finalize();
}

void f_d333e566(inout vec4 vertex) {
    f_f52ac82d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a3a413ca(vertex);
    finalize();
}

void f_526f7915(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7fa2c79b();
    f_a3a413ca(vertex);
    finalize();
}

void f_eed23572(inout vec4 vertex, float speed) {
    f_a3a413ca(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_8ed3893f(inout vec4 vertex) {
    f_a3a413ca(vertex);
    f_f52ac82d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


const ivec3 MP_T[40] = ivec3[40](
    ivec3(2, 0, 0),
    ivec3(2, 0, 42),
    ivec3(2, 42, 0),
    ivec3(2, 42, 42),
    ivec3(8, 0, 0),
    ivec3(8, 0, 170),
    ivec3(8, 170, 0),
    ivec3(8, 170, 170),
    ivec3(19, 21, 21),
    ivec3(19, 21, 63),
    ivec3(19, 21, 64),
    ivec3(19, 63, 21),
    ivec3(19, 63, 63),
    ivec3(19, 64, 21),
    ivec3(19, 64, 64),
    ivec3(40, 0, 0),
    ivec3(40, 0, 42),
    ivec3(40, 42, 42),
    ivec3(61, 21, 21),
    ivec3(61, 21, 63),
    ivec3(61, 42, 0),
    ivec3(61, 63, 21),
    ivec3(61, 63, 63),
    ivec3(62, 21, 21),
    ivec3(62, 21, 64),
    ivec3(62, 42, 0),
    ivec3(62, 64, 21),
    ivec3(62, 64, 64),
    ivec3(77, 85, 85),
    ivec3(77, 85, 255),
    ivec3(77, 255, 85),
    ivec3(77, 255, 255),
    ivec3(162, 0, 0),
    ivec3(162, 0, 170),
    ivec3(162, 170, 170),
    ivec3(247, 85, 85),
    ivec3(247, 85, 255),
    ivec3(247, 170, 0),
    ivec3(247, 255, 85),
    ivec3(247, 255, 255)
);

bool mp_hud(ivec3 c) {
    for (int i = 0; i < 40; i++) if (c == MP_T[i]) return true;
    return false;
}

void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));
    if (ProjMat[3][3] > 0.5 && mp_hud(iColor)) {
        float mp_w = 2.0 / ProjMat[0][0];
        vertex.x += min(0.0, 4.0 - (mp_w - 420.0) / 2.0);
    }


    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_f6332758(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_f52ac82d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a3a413ca(vertex);
            f_f52ac82d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_59c9beac(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_59c9beac(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_d333e566(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_d333e566(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_eed23572(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_8ed3893f(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_014e1b26(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_59c9beac(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_f506c5f6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_d333e566(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_526f7915(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_eed23572(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_014e1b26(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_59c9beac(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_f506c5f6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_d333e566(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_526f7915(vertex);
        return;
    }
    

    
    f_a3a413ca(vertex);
    f_f52ac82d();
    finalize();
}