#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_700560cd(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_8dd858b5() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_fd21b315(inout vec4 vertex) {
    f_700560cd(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_8dd858b5();
    }
    finalize();
}



void f_0cf147ba() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_5a626cfc() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_e8bbda31(inout vec4 vertex) {
    f_700560cd(vertex);
    f_0cf147ba();
    finalize();
}

void f_7ab1ea7d(inout vec4 vertex) {
    f_700560cd(vertex);
    f_8dd858b5();
    f_5a626cfc();
    finalize();
}

void f_2e0241b3(inout vec4 vertex) {
    f_700560cd(vertex);
    f_5a626cfc();
    f_0cf147ba();
    finalize();
}

void f_1f70a28d(inout vec4 vertex) {
    f_8dd858b5();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_700560cd(vertex);
    finalize();
}

void f_1f264ce9(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0cf147ba();
    f_700560cd(vertex);
    finalize();
}

void f_3a4802b7(inout vec4 vertex, float speed) {
    f_700560cd(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_3ada1eca(inout vec4 vertex) {
    f_700560cd(vertex);
    f_8dd858b5();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_fd21b315(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_8dd858b5();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_700560cd(vertex);
            f_8dd858b5();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_7ab1ea7d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_7ab1ea7d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_1f70a28d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_1f70a28d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_3a4802b7(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_3ada1eca(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_e8bbda31(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_7ab1ea7d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_2e0241b3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_1f70a28d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_1f264ce9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_3a4802b7(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_e8bbda31(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_7ab1ea7d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_2e0241b3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_1f70a28d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_1f264ce9(vertex);
        return;
    }
    

    
    f_700560cd(vertex);
    f_8dd858b5();
    finalize();
}