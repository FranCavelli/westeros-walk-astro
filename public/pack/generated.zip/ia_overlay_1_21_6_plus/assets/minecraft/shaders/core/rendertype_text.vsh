#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_4a482b71(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_fb60f519() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_13767b3e(inout vec4 vertex) {
    f_4a482b71(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_fb60f519();
    }
    finalize();
}



void f_8993cffb() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7bdc220d() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_86c06770(inout vec4 vertex) {
    f_4a482b71(vertex);
    f_8993cffb();
    finalize();
}

void f_ad21e75e(inout vec4 vertex) {
    f_4a482b71(vertex);
    f_fb60f519();
    f_7bdc220d();
    finalize();
}

void f_fb32fc73(inout vec4 vertex) {
    f_4a482b71(vertex);
    f_7bdc220d();
    f_8993cffb();
    finalize();
}

void f_e4549274(inout vec4 vertex) {
    f_fb60f519();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_4a482b71(vertex);
    finalize();
}

void f_b1d01c63(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_8993cffb();
    f_4a482b71(vertex);
    finalize();
}

void f_b347dcd0(inout vec4 vertex, float speed) {
    f_4a482b71(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_73c7aeb9(inout vec4 vertex) {
    f_4a482b71(vertex);
    f_fb60f519();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_13767b3e(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_fb60f519();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_4a482b71(vertex);
            f_fb60f519();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_ad21e75e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_ad21e75e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_e4549274(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_e4549274(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_b347dcd0(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_73c7aeb9(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_86c06770(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_ad21e75e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_fb32fc73(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_e4549274(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_b1d01c63(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_b347dcd0(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_86c06770(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_ad21e75e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_fb32fc73(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_e4549274(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_b1d01c63(vertex);
        return;
    }
    

    
    f_4a482b71(vertex);
    f_fb60f519();
    finalize();
}