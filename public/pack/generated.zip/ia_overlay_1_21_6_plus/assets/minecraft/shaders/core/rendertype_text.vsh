#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_502f8460(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_62baecfc() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_c7e74e6e(inout vec4 vertex) {
    f_502f8460(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_62baecfc();
    }
    finalize();
}



void f_0671cca6() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_b89de71c() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_ab0b9c03(inout vec4 vertex) {
    f_502f8460(vertex);
    f_0671cca6();
    finalize();
}

void f_b4f919b4(inout vec4 vertex) {
    f_502f8460(vertex);
    f_62baecfc();
    f_b89de71c();
    finalize();
}

void f_ef964a8e(inout vec4 vertex) {
    f_502f8460(vertex);
    f_b89de71c();
    f_0671cca6();
    finalize();
}

void f_0e64a577(inout vec4 vertex) {
    f_62baecfc();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_502f8460(vertex);
    finalize();
}

void f_0638051d(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0671cca6();
    f_502f8460(vertex);
    finalize();
}

void f_39e9254e(inout vec4 vertex, float speed) {
    f_502f8460(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_d0bf8fa3(inout vec4 vertex) {
    f_502f8460(vertex);
    f_62baecfc();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_c7e74e6e(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_62baecfc();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_502f8460(vertex);
            f_62baecfc();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b4f919b4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b4f919b4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_0e64a577(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_0e64a577(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_39e9254e(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_d0bf8fa3(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_ab0b9c03(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b4f919b4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_ef964a8e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_0e64a577(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_0638051d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_39e9254e(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_ab0b9c03(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b4f919b4(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_ef964a8e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_0e64a577(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_0638051d(vertex);
        return;
    }
    

    
    f_502f8460(vertex);
    f_62baecfc();
    finalize();
}